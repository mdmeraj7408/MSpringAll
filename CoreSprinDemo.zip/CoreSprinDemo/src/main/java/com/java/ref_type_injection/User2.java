package com.java.ref_type_injection;

public class User2 {
private int b;

public int getB() {
	return b;
}

public void setB(int b) {
	this.b = b;
}

public User2() {
	super();
	
}

@Override
public String toString() {
	return "User2 [b=" + b + "]";
}

}
