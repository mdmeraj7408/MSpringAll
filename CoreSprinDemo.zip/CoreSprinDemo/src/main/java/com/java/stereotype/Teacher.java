package com.java.stereotype;

public class Teacher {

}
