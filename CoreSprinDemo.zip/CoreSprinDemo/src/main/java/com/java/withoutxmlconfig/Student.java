package com.java.withoutxmlconfig;

import org.springframework.stereotype.Component;

@Component("student")
public class Student {
public  void toAdd()
{
	  int a=20;
	  int b=30;
	  System.out.println("Value of :"+(a+b));
			  
}
public static void looping()
{
	System.out.println("Print Tab Of :2");
	for(int i=0;i<=10;i++)
	{
		System.out.println("|"+i*2+"|");
	}
}
}
