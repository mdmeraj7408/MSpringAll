package com.java.spel.parser;

import java.util.ArrayList;
import java.util.List;

public class CarPark {
	private List<Car> cars = new ArrayList<>();
}
